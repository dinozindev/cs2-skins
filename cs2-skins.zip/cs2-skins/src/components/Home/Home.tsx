
const Home = () => {
  return (
    <>
    <h1>Home</h1>
    <nav>
        <ul>
        </ul>
    </nav>
    </>
    
  )
}

export default Home