import { useState } from "react";
import styled from "styled-components";
import useFetchCollection from "../useFetch/useFetchCollection";

const CollectionMainDiv = styled.div`
    max-width: 100%;
    height: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
`

const CollectionDiv = styled.div`
    width: 50%;
`

const CollectionCard = styled.div`
    p {
        margin-bottom: 1.25rem;
        font-weight: 700;
        color: white;
    }
    text-align: center;
    margin: 2rem;
    background-color: grey;
    padding: 2rem;
    border-radius: 8px;
    cursor: pointer;
`

const CollectionDetails = styled.div`
    text-align: center;
    width: 50%;
    display:flex;
    flex-direction: column;
    align-items: center;
    gap: 2rem;
    img {
        height: 250px;
        width: 300px;
    }
`

const CollectionSkinCard = styled.div`
    background-color: lightgrey;
    border-radius: 0.5rem;
    padding: 0.75rem;
    height: 300px;
    img {
        height: 250px;
        width: 300px;
    }

    &:hover {
        scale: 1.02;
        transition: 0.5s;
        cursor: pointer;
    }
`

const Collections = () => {
    const { data, loading, error } = useFetchCollection('https://bymykel.github.io/CSGO-API/api/en/collections.json'); // API URL to connect to CSGO-API
    const [collectionID, setCollectionID] = useState('');

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const filteredCollection = data?.filter(collection => !collection.name.includes('Graffiti')) // Removes graffiti collections

    const handleFilteredCollection = (collection_id: string) => {
        setCollectionID(collection_id)
    }

    // quando clicar em uma coleção, esconder as demais e mostrar apenas a clicada.
    return (
        <>
            <h1>Collections:  </h1>
            <CollectionMainDiv>
                <CollectionDiv>
                    {filteredCollection?.map(collection => (
                        <CollectionCard key={collection.id} onClick={() => handleFilteredCollection(collection.id)}>
                            <p>{collection.name}</p>
                            <img src={collection.image} alt="" />
                        </CollectionCard>
                    ))}
                </CollectionDiv>
                {
                    filteredCollection?.filter(collection => collection.id === collectionID).map(collection => (
                        <>
                            <CollectionDetails key={collection.id}>
                                <h1>{collection.name}</h1>
                                <img src={collection.image} alt="" />
                                {collection.contains.map(skin => (
                                    <CollectionSkinCard key={skin.id}>
                                        <p>{skin.name}</p>
                                        <p>{skin.rarity.name}</p>
                                        <img src={skin.image} alt="" />
                                    </CollectionSkinCard>
                                ))}
                            </CollectionDetails>
                        </>
                    ))
                }
            </CollectionMainDiv>
        </>
    );
};

export default Collections;